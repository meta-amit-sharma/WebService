package com.metacube.employeedata;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;

/**
 * this class contains APIs which returns output as per request from the client
 * @author 
 *
 */
@Path("/employee")
public class Employee {

	/**
	 * Method which returns list of all employee
	 * @return html formated employee list
	 */
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getAllEmployees(){
		JSONParser parser = new JSONParser();
		String jObj = getFileContent();
		
		try {
			JSONObject json = (JSONObject) parser.parse(jObj);
			JSONArray array = (JSONArray) json.get("employee");
			String employeeList = "";
			for ( int i = 0 ; i < array.size() ; i++ ){
				JSONObject employee = ((JSONObject) array.get(i));
				employeeList += "<div class='col'>" + employee.get("id") + "</div><div class='col'>" + employee.get("name") + "</div>";
			}
			employeeList = "<html><style>.col{float: left;width: 50%;}.container{width: 400px;margin: 0 auto;}</style><body><div class='container'><div class='col'>Id</div><div class='col'>Name</div>" + employeeList + "</div></body></html>";
			return employeeList;
		} catch (ParseException e) {
			e.getStackTrace();
			System.out.println("json error");
			return e.toString();
		}
	}
	
	/**
	 * Method which return employee detail with particuolar id
	 * @param id - id of employee
	 * @return employee detail in html format
	 * @throws ParseException - exception in parsing
	 */
	@GET
	@Path("{id}")
	@Produces(MediaType.TEXT_HTML)
	public String getEmployeeById(@PathParam("id") String id){
		JSONParser parser = new JSONParser();
		String jObj = getFileContent();
		
		try {
			JSONObject json = (JSONObject) parser.parse(jObj);
			JSONArray array = (JSONArray) json.get("employee");
			String employeeList = "";
			JSONObject employee;
			for ( int i = 0 ; i < array.size() ; i++ ){
				employee = ((JSONObject) array.get(i));
				if(employee.get("id").toString().equalsIgnoreCase(id)){
					employeeList += "<div class='col'>" + employee.get("id") + "</div><div class='col'>" + employee.get("name") + "</div>";
					break;
				}
			}
			employeeList = "<html><style>.col{float: left;width: 50%;}.container{width: 400px;margin: 0 auto;}</style><body><div class='container'><div class='col'>Id</div><div class='col'>Name</div>" + employeeList + "</div></body></html>";
			return employeeList;
		} catch (ParseException e) {
			e.getStackTrace();
			System.out.println("json error");
			return e.toString();
		}
		/*return null;*/
	}
	
	/**
	 * Method which returns all employees detail with particular name
	 * @param employeeName - name of employee
	 * @return employees detail in html format
	 * @throws ParseException - exception in parsing
	 */
	@GET
	@Path("all")
	@Produces(MediaType.TEXT_HTML)
	public String getEmployeesByName(@QueryParam("name") String employeeName){
		JSONParser parser = new JSONParser();
		String jObj = getFileContent();
		
		try {
			JSONObject json = (JSONObject) parser.parse(jObj);
			JSONArray array = (JSONArray) json.get("employee");
			String employeeList = "";
			JSONObject employee;
			for ( int i = 0 ; i < array.size() ; i++ ){
				employee = ((JSONObject) array.get(i));
				if(employee.get("name").toString().equalsIgnoreCase(employeeName)){
					employeeList += "<div class='col'>" + employee.get("id") + "</div><div class='col'>" + employee.get("name") + "</div>";
				}
			}
			employeeList = "<html><style>.col{float: left;width: 50%;}.container{width: 400px;margin: 0 auto;}</style><body><div class='container'><div class='col'>Id</div><div class='col'>Name</div>" + employeeList + "</div></body></html>";
			return employeeList;
		} catch (ParseException e) {
			e.getStackTrace();
			System.out.println("json error");
			return e.toString();
		}
	}
	
	/**
	 * Method which add employee after creating
	 * @param employee - employee name in json format
	 * @return message of success
	 * @throws ParseException - exception in parsing
	 */
	@POST
	@Path("create")
	@Produces(MediaType.TEXT_PLAIN)
	public String createEmployee(@QueryParam("employee") String employee) throws ParseException{
		JSONParser parser = new JSONParser();
		JSONObject employeeJson = (JSONObject) parser.parse(employee);
		JSONObject employees = (JSONObject) parser.parse(getFileContent());
		JSONArray array = (JSONArray) employees.get("employee");
		int id = 0;
		if(array.size() > 0) {
			id = Integer.parseInt(((JSONObject) array.get(array.size() - 1)).get("id").toString());
		}
		create(id + 1, employeeJson);
		array.add(employeeJson);
		insertIntoFile(employees.toString());
		return "Inserted";
	}
	
	/**
	 * Method which delete the employee with particular id
	 * @param id - id of employee
	 * @return message of success
	 * @throws ParseException - exception in parsing
	 */
	@GET
	@Path("delete")
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteEmployee(@QueryParam("id") String id) throws ParseException {
		String message = "Employee Not Found";
		JSONParser parser = new JSONParser();
		
		JSONObject employees = (JSONObject) parser.parse(getFileContent());
		JSONArray array = (JSONArray) employees.get("employee");
		JSONObject employee;
		for ( int i = 0 ; i < array.size() ; i++ ){
			employee = ((JSONObject) array.get(i));
			if(employee.get("id").toString().equalsIgnoreCase(id)){
				array.remove(employee);
				message = "deleted";
				break;
			}
		}
		insertIntoFile(employees.toString());
		return message;
	}
	
	/**
	 * create employee
	 * @param id - id of created employee
	 * @param employee - detail of employee in json format
	 */
	private static void create(int id, JSONObject employee){
		employee.put("id", Integer.toString(id));
	}
	
	/**
	 * Method which returns file content
	 * @return
	 */
	private String getFileContent(){
		File file = new File("C:\\Users\\admin\\workspace\\WebService-Session-2\\src\\employee.txt");
		String jObj="";
		try {
			Scanner sc = new Scanner(file);
			while(sc.hasNextLine()){
				jObj += sc.nextLine();
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		return jObj;
	}
	
	/**
	 * Method which insert employee data into file
	 * @param data - employee data
	 */
	private void insertIntoFile(String data){
		File file = new File("C:\\Users\\admin\\workspace\\WebService-Session-2\\src\\employee.txt");
		OutputStream os = null;
        try {
            os = new FileOutputStream(file);
            os.write(data.getBytes(), 0, data.length());
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
