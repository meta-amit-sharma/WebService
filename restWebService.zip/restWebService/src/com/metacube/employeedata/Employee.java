package com.metacube.employeedata;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;

@Path("/hello")
public class Employee {

	@GET
	//@Path("set")
	@Produces(MediaType.TEXT_PLAIN)
	public String getHello(@QueryParam("id") String id){
		
		JSONParser parser = new JSONParser();
		File file = new File("C:\\Users\\Amit\\Desktop\\satyamWorkSpace\\restWebService\\src\\employee.txt");
		String jObj="";
		try {
			Scanner sc =new Scanner(file);
			while(sc.hasNextLine()){
				jObj += sc.nextLine();
			}
			jObj = "{" + jObj + "]}";
			System.out.println("line="+jObj);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("file error");
		}
		try {
			System.out.println("the employees are");
			JSONObject json = (JSONObject) parser.parse(jObj);
			JSONArray array = (JSONArray) json.get("employee");
			for ( int i = 0 ; i < array.size() ; i++ ){
				if(((JSONObject) array.get(i)).get("name").toString().equalsIgnoreCase(id)){
					System.out.println(((JSONObject) array.get(i)));
					//break;
				}
			}
			return json.toString();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.getStackTrace();
			System.out.println("json error");
			return e.toString();
		}
	}
	
	@GET
	@Path("something")
	@Produces(MediaType.TEXT_PLAIN)
	public String getHello1(){
		return "hello";
	}
}
